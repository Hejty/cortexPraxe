function Copyright () {
    return (
        <div className="text-center bg-[#2e2d2d]">
            <p className="p-4 text-white">
                <span className="text-[#f55d4b] font-['Satisfy']">
                    PHP Academy</span> is provided and operated by © Cortex 2023 
            </p>
        </div>
    );
}

export default Copyright;